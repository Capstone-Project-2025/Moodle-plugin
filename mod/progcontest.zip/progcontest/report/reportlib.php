<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Helper functions for the progcontest reports.
 *
 * @package   mod_progcontest
 * @copyright 2008 Jamie Pratt
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */


defined('MOODLE_INTERNAL') || die();

require_once($CFG->dirroot . '/mod/progcontest/lib.php');
require_once($CFG->libdir . '/filelib.php');

/**
 * Takes an array of objects and constructs a multidimensional array keyed by
 * the keys it finds on the object.
 * @param array $datum an array of objects with properties on the object
 * including the keys passed as the next param.
 * @param array $keys Array of strings with the names of the properties on the
 * objects in datum that you want to index the multidimensional array by.
 * @param bool $keysunique If there is not only one object for each
 * combination of keys you are using you should set $keysunique to true.
 * Otherwise all the object will be added to a zero based array. So the array
 * returned will have count($keys) + 1 indexs.
 * @return array multidimensional array properly indexed.
 */
function progcontest_report_index_by_keys($datum, $keys, $keysunique = true) {
    if (!$datum) {
        return array();
    }
    $key = array_shift($keys);
    $datumkeyed = array();
    foreach ($datum as $data) {
        if ($keys || !$keysunique) {
            $datumkeyed[$data->{$key}][]= $data;
        } else {
            $datumkeyed[$data->{$key}]= $data;
        }
    }
    if ($keys) {
        foreach ($datumkeyed as $datakey => $datakeyed) {
            $datumkeyed[$datakey] = progcontest_report_index_by_keys($datakeyed, $keys, $keysunique);
        }
    }
    return $datumkeyed;
}

function progcontest_report_unindex($datum) {
    if (!$datum) {
        return $datum;
    }
    $datumunkeyed = array();
    foreach ($datum as $value) {
        if (is_array($value)) {
            $datumunkeyed = array_merge($datumunkeyed, progcontest_report_unindex($value));
        } else {
            $datumunkeyed[] = $value;
        }
    }
    return $datumunkeyed;
}

/**
 * Are there any questions in this progcontest?
 * @param int $progcontestid the progcontest id.
 */
function progcontest_has_questions($progcontestid) {
    global $DB;
    return $DB->record_exists('progcontest_slots', array('progcontestid' => $progcontestid));
}

/**
 * Get the slots of real questions (not descriptions) in this progcontest, in order.
 * @param object $progcontest the progcontest.
 * @return array of slot => $question object with fields
 *      ->slot, ->id, ->maxmark, ->number, ->length.
 */
function progcontest_report_get_significant_questions($progcontest) {
    global $DB;

    $qsbyslot = $DB->get_records_sql("
            SELECT slot.slot,
                   q.id,
                   q.qtype,
                   q.length,
                   slot.maxmark

              FROM {question} q
              JOIN {progcontest_slots} slot ON slot.questionid = q.id

             WHERE slot.progcontestid = ?
               AND q.length > 0

          ORDER BY slot.slot", array($progcontest->id));

    $number = 1;
    foreach ($qsbyslot as $question) {
        $question->number = $number;
        $number += $question->length;
        $question->type = $question->qtype;
    }

    return $qsbyslot;
}

/**
 * @param object $progcontest the progcontest settings.
 * @return bool whether, for this progcontest, it is possible to filter attempts to show
 *      only those that gave the final grade.
 */
function progcontest_report_can_filter_only_graded($progcontest) {
    return $progcontest->attempts != 1 && $progcontest->grademethod != progcontest_GRADEAVERAGE;
}

/**
 * This is a wrapper for {@link progcontest_report_grade_method_sql} that takes the whole progcontest object instead of just the grading method
 * as a param. See definition for {@link progcontest_report_grade_method_sql} below.
 *
 * @param object $progcontest
 * @param string $progcontestattemptsalias sql alias for 'progcontest_attempts' table
 * @return string sql to test if this is an attempt that will contribute towards the grade of the user
 */
function progcontest_report_qm_filter_select($progcontest, $progcontestattemptsalias = 'progcontesta') {
    if ($progcontest->attempts == 1) {
        // This progcontest only allows one attempt.
        return '';
    }
    return progcontest_report_grade_method_sql($progcontest->grademethod, $progcontestattemptsalias);
}

/**
 * Given a progcontest grading method return sql to test if this is an
 * attempt that will be contribute towards the grade of the user. Or return an
 * empty string if the grading method is progcontest_GRADEAVERAGE and thus all attempts
 * contribute to final grade.
 *
 * @param string $grademethod progcontest grading method.
 * @param string $progcontestattemptsalias sql alias for 'progcontest_attempts' table
 * @return string sql to test if this is an attempt that will contribute towards the graded of the user
 */
function progcontest_report_grade_method_sql($grademethod, $progcontestattemptsalias = 'progcontesta') {
    switch ($grademethod) {
        case progcontest_GRADEHIGHEST :
            return "($progcontestattemptsalias.state = 'finished' AND NOT EXISTS (
                           SELECT 1 FROM {progcontest_attempts} qa2
                            WHERE qa2.progcontest = $progcontestattemptsalias.progcontest AND
                                qa2.userid = $progcontestattemptsalias.userid AND
                                 qa2.state = 'finished' AND (
                COALESCE(qa2.sumgrades, 0) > COALESCE($progcontestattemptsalias.sumgrades, 0) OR
               (COALESCE(qa2.sumgrades, 0) = COALESCE($progcontestattemptsalias.sumgrades, 0) AND qa2.attempt < $progcontestattemptsalias.attempt)
                                )))";

        case progcontest_GRADEAVERAGE :
            return '';

        case progcontest_ATTEMPTFIRST :
            return "($progcontestattemptsalias.state = 'finished' AND NOT EXISTS (
                           SELECT 1 FROM {progcontest_attempts} qa2
                            WHERE qa2.progcontest = $progcontestattemptsalias.progcontest AND
                                qa2.userid = $progcontestattemptsalias.userid AND
                                 qa2.state = 'finished' AND
                               qa2.attempt < $progcontestattemptsalias.attempt))";

        case progcontest_ATTEMPTLAST :
            return "($progcontestattemptsalias.state = 'finished' AND NOT EXISTS (
                           SELECT 1 FROM {progcontest_attempts} qa2
                            WHERE qa2.progcontest = $progcontestattemptsalias.progcontest AND
                                qa2.userid = $progcontestattemptsalias.userid AND
                                 qa2.state = 'finished' AND
                               qa2.attempt > $progcontestattemptsalias.attempt))";
    }
}

/**
 * Get the number of students whose score was in a particular band for this progcontest.
 * @param number $bandwidth the width of each band.
 * @param int $bands the number of bands
 * @param int $progcontestid the progcontest id.
 * @param \core\dml\sql_join $usersjoins (joins, wheres, params) to get enrolled users
 * @return array band number => number of users with scores in that band.
 */
function progcontest_report_grade_bands($bandwidth, $bands, $progcontestid, \core\dml\sql_join $usersjoins = null) {
    global $DB;
    if (!is_int($bands)) {
        debugging('$bands passed to progcontest_report_grade_bands must be an integer. (' .
                gettype($bands) . ' passed.)', DEBUG_DEVELOPER);
        $bands = (int) $bands;
    }

    if ($usersjoins && !empty($usersjoins->joins)) {
        $userjoin = "JOIN {user} u ON u.id = qg.userid
                {$usersjoins->joins}";
        $usertest = $usersjoins->wheres;
        $params = $usersjoins->params;
    } else {
        $userjoin = '';
        $usertest = '1=1';
        $params = array();
    }
    $sql = "
SELECT band, COUNT(1)

FROM (
    SELECT FLOOR(qg.grade / :bandwidth) AS band
      FROM {progcontest_grades} qg
    $userjoin
    WHERE $usertest AND qg.progcontest = :progcontestid
) subquery

GROUP BY
    band

ORDER BY
    band";

    $params['progcontestid'] = $progcontestid;
    $params['bandwidth'] = $bandwidth;

    $data = $DB->get_records_sql_menu($sql, $params);

    // We need to create array elements with values 0 at indexes where there is no element.
    $data = $data + array_fill(0, $bands + 1, 0);
    ksort($data);

    // Place the maximum (perfect grade) into the last band i.e. make last
    // band for example 9 <= g <=10 (where 10 is the perfect grade) rather than
    // just 9 <= g <10.
    $data[$bands - 1] += $data[$bands];
    unset($data[$bands]);

    return $data;
}

function progcontest_report_highlighting_grading_method($progcontest, $qmsubselect, $qmfilter) {
    if ($progcontest->attempts == 1) {
        return '<p>' . get_string('onlyoneattemptallowed', 'progcontest_overview') . '</p>';

    } else if (!$qmsubselect) {
        return '<p>' . get_string('allattemptscontributetograde', 'progcontest_overview') . '</p>';

    } else if ($qmfilter) {
        return '<p>' . get_string('showinggraded', 'progcontest_overview') . '</p>';

    } else {
        return '<p>' . get_string('showinggradedandungraded', 'progcontest_overview',
                '<span class="gradedattempt">' . progcontest_get_grading_option_name($progcontest->grademethod) .
                '</span>') . '</p>';
    }
}

/**
 * Get the feedback text for a grade on this progcontest. The feedback is
 * processed ready for display.
 *
 * @param float $grade a grade on this progcontest.
 * @param int $progcontestid the id of the progcontest object.
 * @return string the comment that corresponds to this grade (empty string if there is not one.
 */
function progcontest_report_feedback_for_grade($grade, $progcontestid, $context) {
    global $DB;

    static $feedbackcache = array();

    if (!isset($feedbackcache[$progcontestid])) {
        $feedbackcache[$progcontestid] = $DB->get_records('progcontest_feedback', array('progcontestid' => $progcontestid));
    }

    // With CBM etc, it is possible to get -ve grades, which would then not match
    // any feedback. Therefore, we replace -ve grades with 0.
    $grade = max($grade, 0);

    $feedbacks = $feedbackcache[$progcontestid];
    $feedbackid = 0;
    $feedbacktext = '';
    $feedbacktextformat = FORMAT_MOODLE;
    foreach ($feedbacks as $feedback) {
        if ($feedback->mingrade <= $grade && $grade < $feedback->maxgrade) {
            $feedbackid = $feedback->id;
            $feedbacktext = $feedback->feedbacktext;
            $feedbacktextformat = $feedback->feedbacktextformat;
            break;
        }
    }

    // Clean the text, ready for display.
    $formatoptions = new stdClass();
    $formatoptions->noclean = true;
    $feedbacktext = file_rewrite_pluginfile_urls($feedbacktext, 'pluginfile.php',
            $context->id, 'mod_progcontest', 'feedback', $feedbackid);
    $feedbacktext = format_text($feedbacktext, $feedbacktextformat, $formatoptions);

    return $feedbacktext;
}

/**
 * Format a number as a percentage out of $progcontest->sumgrades
 * @param number $rawgrade the mark to format.
 * @param object $progcontest the progcontest settings
 * @param bool $round whether to round the results ot $progcontest->decimalpoints.
 */
function progcontest_report_scale_summarks_as_percentage($rawmark, $progcontest, $round = true) {
    if ($progcontest->sumgrades == 0) {
        return '';
    }
    if (!is_numeric($rawmark)) {
        return $rawmark;
    }

    $mark = $rawmark * 100 / $progcontest->sumgrades;
    if ($round) {
        $mark = progcontest_format_grade($progcontest, $mark);
    }

    return get_string('percents', 'moodle', $mark);
}

/**
 * Returns an array of reports to which the current user has access to.
 * @return array reports are ordered as they should be for display in tabs.
 */
function progcontest_report_list($context) {
    global $DB;
    static $reportlist = null;
    if (!is_null($reportlist)) {
        return $reportlist;
    }

    $reports = $DB->get_records('progcontest_reports', null, 'displayorder DESC', 'name, capability');
    $reportdirs = core_component::get_plugin_list('progcontest');

    // Order the reports tab in descending order of displayorder.
    $reportcaps = array();
    foreach ($reports as $key => $report) {
        if (array_key_exists($report->name, $reportdirs)) {
            $reportcaps[$report->name] = $report->capability;
        }
    }

    // Add any other reports, which are on disc but not in the DB, on the end.
    foreach ($reportdirs as $reportname => $notused) {
        if (!isset($reportcaps[$reportname])) {
            $reportcaps[$reportname] = null;
        }
    }
    $reportlist = array();
    foreach ($reportcaps as $name => $capability) {
        if (empty($capability)) {
            $capability = 'mod/progcontest:viewreports';
        }
        if (has_capability($capability, $context)) {
            $reportlist[] = $name;
        }
    }
    return $reportlist;
}

/**
 * Create a filename for use when downloading data from a progcontest report. It is
 * expected that this will be passed to flexible_table::is_downloading, which
 * cleans the filename of bad characters and adds the file extension.
 * @param string $report the type of report.
 * @param string $courseshortname the course shortname.
 * @param string $progcontestname the progcontest name.
 * @return string the filename.
 */
function progcontest_report_download_filename($report, $courseshortname, $progcontestname) {
    return $courseshortname . '-' . format_string($progcontestname, true) . '-' . $report;
}

/**
 * Get the default report for the current user.
 * @param object $context the progcontest context.
 */
function progcontest_report_default_report($context) {
    $reports = progcontest_report_list($context);
    return reset($reports);
}

/**
 * Generate a message saying that this progcontest has no questions, with a button to
 * go to the edit page, if the user has the right capability.
 * @param object $progcontest the progcontest settings.
 * @param object $cm the course_module object.
 * @param object $context the progcontest context.
 * @return string HTML to output.
 */
function progcontest_no_questions_message($progcontest, $cm, $context) {
    global $OUTPUT;

    $output = '';
    $output .= $OUTPUT->notification(get_string('noquestions', 'progcontest'));
    if (has_capability('mod/progcontest:manage', $context)) {
        $output .= $OUTPUT->single_button(new moodle_url('/mod/progcontest/edit.php',
        array('cmid' => $cm->id)), get_string('editprogcontest', 'progcontest'), 'get');
    }

    return $output;
}

/**
 * Should the grades be displayed in this report. That depends on the progcontest
 * display options, and whether the progcontest is graded.
 * @param object $progcontest the progcontest settings.
 * @param context $context the progcontest context.
 * @return bool
 */
function progcontest_report_should_show_grades($progcontest, context $context) {
    if ($progcontest->timeclose && time() > $progcontest->timeclose) {
        $when = mod_progcontest_display_options::AFTER_CLOSE;
    } else {
        $when = mod_progcontest_display_options::LATER_WHILE_OPEN;
    }
    $reviewoptions = mod_progcontest_display_options::make_from_progcontest($progcontest, $when);

    return progcontest_has_grades($progcontest) &&
            ($reviewoptions->marks >= question_display_options::MARK_AND_MAX ||
            has_capability('moodle/grade:viewhidden', $context));
}
