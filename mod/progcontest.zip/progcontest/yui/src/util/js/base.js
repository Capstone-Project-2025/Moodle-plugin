/**
 * The Moodle.mod_progcontest.util classes provide progcontest-related utility functions.
 *
 * @module moodle-mod_progcontest-util
 * @main
 */

Y.namespace('Moodle.mod_progcontest.util');

/**
 * A collection of general utility functions for use in progcontest.
 *
 * @class Moodle.mod_progcontest.util
 * @static
 */
