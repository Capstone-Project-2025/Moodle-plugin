<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace mod_progcontest\backup;

defined('MOODLE_INTERNAL') || die();

global $CFG;
require_once($CFG->libdir . "/phpunit/classes/restore_date_testcase.php");

/**
 * Restore date tests.
 *
 * @package    mod_progcontest
 * @copyright  2017 onwards Ankit Agarwal <ankit.agrr@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class restore_date_test extends \restore_date_testcase {

    /**
     * Test restore dates.
     */
    public function test_restore_dates() {
        global $DB, $USER;

        // Create progcontest data.
        $record = ['timeopen' => 100, 'timeclose' => 100, 'timemodified' => 100, 'tiemcreated' => 100, 'questionsperpage' => 0,
            'grade' => 100.0, 'sumgrades' => 2];
        list($course, $progcontest) = $this->create_course_and_module('progcontest', $record);

        // Create questions.
        $questiongenerator = $this->getDataGenerator()->get_plugin_generator('core_question');
        $cat = $questiongenerator->create_question_category();
        $saq = $questiongenerator->create_question('shortanswer', null, array('category' => $cat->id));
        // Add to the progcontest.
        progcontest_add_progcontest_question($saq->id, $progcontest);

        // Create an attempt.
        $timestamp = 100;
        $progcontestobj = \progcontest::create($progcontest->id);
        $attempt = progcontest_create_attempt($progcontestobj, 1, false, $timestamp, false);
        $quba = \question_engine::make_questions_usage_by_activity('mod_progcontest', $progcontestobj->get_context());
        $quba->set_preferred_behaviour($progcontestobj->get_progcontest()->preferredbehaviour);
        progcontest_start_new_attempt($progcontestobj, $quba, $attempt, 1, $timestamp);
        progcontest_attempt_save_started($progcontestobj, $quba, $attempt);

        // Programmingcontest grade.
        $grade = new \stdClass();
        $grade->progcontest = $progcontest->id;
        $grade->userid = $USER->id;
        $grade->grade = 8.9;
        $grade->timemodified = $timestamp;
        $grade->id = $DB->insert_record('progcontest_grades', $grade);

        // User override.
        $override = (object)[
            'progcontest' => $progcontest->id,
            'groupid' => 0,
            'userid' => $USER->id,
            'sortorder' => 1,
            'timeopen' => 100,
            'timeclose' => 200
        ];
        $DB->insert_record('progcontest_overrides', $override);

        // Set time fields to a constant for easy validation.
        $DB->set_field('progcontest_attempts', 'timefinish', $timestamp);

        // Do backup and restore.
        $newcourseid = $this->backup_and_restore($course);
        $newprogcontest = $DB->get_record('progcontest', ['course' => $newcourseid]);

        $this->assertFieldsNotRolledForward($progcontest, $newprogcontest, ['timecreated', 'timemodified']);
        $props = ['timeclose', 'timeopen'];
        $this->assertFieldsRolledForward($progcontest, $newprogcontest, $props);

        $newattempt = $DB->get_record('progcontest_attempts', ['progcontest' => $newprogcontest->id]);
        $newoverride = $DB->get_record('progcontest_overrides', ['progcontest' => $newprogcontest->id]);
        $newgrade = $DB->get_record('progcontest_grades', ['progcontest' => $newprogcontest->id]);

        // Attempt time checks.
        $diff = $this->get_diff();
        $this->assertEquals($timestamp, $newattempt->timemodified);
        $this->assertEquals($timestamp, $newattempt->timefinish);
        $this->assertEquals($timestamp, $newattempt->timestart);
        $this->assertEquals($timestamp + $diff, $newattempt->timecheckstate); // Should this be rolled?

        // Programmingcontest override time checks.
        $diff = $this->get_diff();
        $this->assertEquals($override->timeopen + $diff, $newoverride->timeopen);
        $this->assertEquals($override->timeclose + $diff, $newoverride->timeclose);

        // Programmingcontest grade time checks.
        $this->assertEquals($grade->timemodified, $newgrade->timemodified);
    }
}
