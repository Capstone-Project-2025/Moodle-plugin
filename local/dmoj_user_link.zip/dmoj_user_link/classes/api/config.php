<?php
namespace local_dmoj_user_link\api;

defined('MOODLE_INTERNAL') || die();

class config {
    public const TOKEN_SECRET = 'secret';
}

